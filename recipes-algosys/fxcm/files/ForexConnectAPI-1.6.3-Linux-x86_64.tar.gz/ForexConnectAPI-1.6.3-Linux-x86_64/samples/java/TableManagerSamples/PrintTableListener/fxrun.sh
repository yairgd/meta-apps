#!/bin/bash
ant run
