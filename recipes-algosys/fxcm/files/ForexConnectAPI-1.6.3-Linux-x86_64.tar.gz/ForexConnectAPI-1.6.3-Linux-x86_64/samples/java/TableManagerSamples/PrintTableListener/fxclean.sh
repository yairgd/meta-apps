#!/bin/bash
ant clean
