#!/bin/bash
ant build
